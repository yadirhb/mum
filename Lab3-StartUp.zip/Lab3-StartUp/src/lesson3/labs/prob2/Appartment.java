package lesson3.labs.prob2;

public class Appartment {
	private int number;
	private double rent;
	
	Appartment(int number, double rent){
		this.number = number;
		this.rent = rent;
	}

	public int getNumber() {
		return number;
	}

	public double getRent() {
		return this.rent;
	}
	
}
