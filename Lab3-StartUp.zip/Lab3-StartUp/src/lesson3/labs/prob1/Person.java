package lesson3.labs.prob1;

public interface Person {
	String getName();
}
