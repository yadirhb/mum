/**
 * 
 */
/**
 * @author 610545
 *
 */
module lesson3 {
}